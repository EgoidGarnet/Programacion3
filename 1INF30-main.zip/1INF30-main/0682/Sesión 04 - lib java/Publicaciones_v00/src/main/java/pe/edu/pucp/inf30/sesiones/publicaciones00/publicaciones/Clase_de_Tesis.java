package pe.edu.pucp.inf30.sesiones.publicaciones00.publicaciones;

public enum Clase_de_Tesis {
    LICENCIATURA, MAESTRIA, DOCTORADO
}
