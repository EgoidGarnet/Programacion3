using System;

namespace Hola_Mundo_VSC
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("¡Hola, Mundo!");
        }
    }
}
